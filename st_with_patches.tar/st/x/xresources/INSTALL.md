### [Xresources](https://wiki.archlinux.org/index.php/x_resources)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    git clone https://github.com/dracula/xresources.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/xresources/archive/master.zip) option and unzip them.

#### Activating theme

Copy or link as a _.Xresources_ file in your home directory.
